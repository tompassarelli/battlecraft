/** @noSelfInFile */
import type { HandleFactory, NativeBehavior, SyncMessage } from "../clientTypes";
import type { Frame } from "../frames";
import type { Unit, Units } from "./units";
export declare class TriggersTimers {
    private readonly handle;
    private readonly units;
    private readonly timers;
    private readonly spellHits;
    private timerOrder;
    private now;
    private readonly registrations;
    private readonly event;
    constructor(handle: HandleFactory, units: Units);
    time(): number;
    hit(target: Unit, due: number, damage: number): void;
    private fire;
    private timerElapsed;
    runDue(frame: number): void;
    deliverSync({ sender, prefix, data }: SyncMessage): void;
    chat(sender: number, message: string): void;
    keyEvent(sender: number, key: number, meta: number, down: boolean): void;
    frameEvent(sender: number, id: number, event: unknown): void;
    handles(frame: Frame, event: unknown): boolean;
    behaviors(slot: number, network: SyncMessage[]): Readonly<Record<string, NativeBehavior>>;
    private triggerBehaviors;
}
