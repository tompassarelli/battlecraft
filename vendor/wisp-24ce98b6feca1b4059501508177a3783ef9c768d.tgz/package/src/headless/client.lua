local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local Map = ____lualib.Map
local Set = ____lualib.Set
local __TS__ArraySome = ____lualib.__TS__ArraySome
local __TS__StringTrim = ____lualib.__TS__StringTrim
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local ____exports = {}
local ____f32 = require("src.sim.f32")
local ____callHash = require("src.headless.callHash")
local ____frames = require("src.headless.frames")
local ____frameRate = require("src.headless.frameRate")
local ____jassFormat = require("src.headless.jassFormat")
local ____lightnings = require("src.headless.lightnings")
local ____cameraCine = require("src.headless.natives.cameraCine")
local ____effects = require("src.headless.natives.effects")
local ____frames_2 = require("src.headless.natives.frames")
local ____math = require("src.headless.natives.math")
local ____preloadText = require("src.headless.natives.preloadText")
local ____sound = require("src.headless.natives.sound")
local ____triggersTimers = require("src.headless.natives.triggersTimers")
local ____units = require("src.headless.natives.units")
local ____textTags = require("src.headless.textTags")
local ____warcraft3Abilities = require("src.headless.warcraft3Abilities")
local ____warcraft3Inventory = require("src.headless.warcraft3Inventory")
local ____warcraft3Natives = require("src.headless.warcraft3Natives")
local ____warcraft3Scenery = require("src.headless.warcraft3Scenery")
do
    local ____jassFormat = require("src.headless.jassFormat")
    ____exports.describeCall = ____jassFormat.describeCall
    ____exports.describeNumber = ____jassFormat.describeNumber
    ____exports.describeValue = ____jassFormat.describeValue
    ____exports.sameCall = ____jassFormat.sameCall
end
do
    local ____sound = require("src.headless.natives.sound")
    ____exports.assertSoundCue = ____sound.assertSoundCue
end
____exports.FRAMES_PER_SECOND = ____frameRate.FRAMES_PER_SECOND
____exports.WISP_LOCAL_NATIVES = {
    GetLocalPlayer = "identifies the client; every local branch starts here",
    GetPlayerId = "names this client's files; no effect",
    BlzSendSyncData = "only the sending client calls it; its message reaches every client as an event",
    PreloadGenClear = "local file output",
    PreloadGenStart = "local file output",
    Preload = "local file output",
    PreloadGenEnd = "local file output",
    Preloader = "local file input, synchronized only through sync data",
    BlzGetAbilityTooltip = "FileIO's local file buffer",
    BlzSetAbilityTooltip = "FileIO's local file buffer",
    DisplayTextToPlayer = "a message on this client: reload results and error reports",
    BlzFrameSetText = "the frame meter's overlay: an existing frame's text on this client",
    BlzFrameSetVisible = "the frame meter's overlay: shows an existing frame on this client",
    TimerGetElapsed = "reads a timer; the reload acknowledgement only reports it",
    BlzGetLocalSpecialEffectX = "the scene report reads an effect's local position",
    BlzGetLocalSpecialEffectY = "the scene report reads an effect's local position",
    BlzGetLocalSpecialEffectZ = "the scene report reads an effect's local position"
}
____exports.HeadlessClient = __TS__Class()
local HeadlessClient = ____exports.HeadlessClient
HeadlessClient.name = "HeadlessClient"
function HeadlessClient.prototype.____constructor(self, options)
    self.textTags = __TS__New(____textTags.TextTags)
    self.lightnings = __TS__New(____lightnings.Lightnings)
    self.textAreaAutoScroll = __TS__New(Map)
    self.heldMouseButtons = __TS__New(Set)
    self.mouseScreenX = 0
    self.mouseScreenY = 0
    self.heldMeta = 0
    self.log = {}
    self.forgotten = 0
    self.forgottenHash = 0
    self.errors = {}
    self.missingNatives = {}
    self.messages = {}
    self.thrown = {}
    self.files = __TS__New(Map)
    self.published = __TS__New(Map)
    self.missedLookups = 0
    self.natives = {}
    self.frame = 0
    self.nextId = 0
    self.heldKeys = __TS__New(Set)
    self.abilities = __TS__New(____warcraft3Abilities.Warcraft3Abilities, options.abilityObjects)
    self.scenery = __TS__New(____warcraft3Scenery.Scenery, options.scenery)
    self.inventory = __TS__New(
        ____warcraft3Inventory.Warcraft3Inventory,
        {
            handle = function(kind) return self:handle(kind) end,
            getUnitTypeId = function(unit) return unit.typeId end,
            readLife = function(unit) return self.units:value(unit, "life") end,
            readMaxLife = function(unit) return self.units:value(unit, "maxLife") end,
            writeLife = function(unit, life) return self.units:setLife(unit, life) end
        },
        options.inventory
    )
    local function handle(kind)
        return self:handle(kind)
    end
    local function frame()
        return self.frame
    end
    self.units = __TS__New(____units.Units, options.unitStates or ({}), handle, self.abilities)
    self.effects = __TS__New(____effects.Effects, handle, options.effectDeaths, frame)
    self.sounds = __TS__New(____sound.Sounds, handle, options.musicSlider or 1, frame)
    self.soundLog = self.sounds.log
    self.camera = __TS__New(____cameraCine.CameraCine, self.scenery, frame)
    self.timers = __TS__New(____triggersTimers.TriggersTimers, handle, self.units)
    self.slot = options.slot
    self.scope = options.scope
    self.preloadText = __TS__New(
        ____preloadText.PreloadText,
        {
            slot = options.slot,
            filePrefix = options.filePrefix,
            stored = options.files,
            files = self.files,
            published = self.published,
            messages = self.messages,
            errors = self.errors,
            missed = function()
                self.missedLookups = self.missedLookups + 1
            end
        }
    )
    local behaviors = self:behaviors(options)
    local ____local = options.localNatives
    local log = self.log
    local function logged(name, parameters, behave)
        repeat
            local ____switch12 = parameters
            local ____cond12 = ____switch12 == 0
            if ____cond12 then
                return function()
                    log[#log + 1] = {name = name, args = {}}
                    return behave()
                end
            end
            ____cond12 = ____cond12 or ____switch12 == 1
            if ____cond12 then
                return function(a)
                    log[#log + 1] = {name = name, args = {a}}
                    return behave(a)
                end
            end
            ____cond12 = ____cond12 or ____switch12 == 2
            if ____cond12 then
                return function(a, b)
                    log[#log + 1] = {name = name, args = {a, b}}
                    return behave(a, b)
                end
            end
            ____cond12 = ____cond12 or ____switch12 == 3
            if ____cond12 then
                return function(a, b, c)
                    log[#log + 1] = {name = name, args = {a, b, c}}
                    return behave(a, b, c)
                end
            end
            ____cond12 = ____cond12 or ____switch12 == 4
            if ____cond12 then
                return function(a, b, c, d)
                    log[#log + 1] = {name = name, args = {a, b, c, d}}
                    return behave(a, b, c, d)
                end
            end
            do
                return function(...)
                    local args = {...}
                    log[#log + 1] = {name = name, args = args}
                    return behave(...)
                end
            end
        until true
    end
    local arity = __TS__New(Map)
    local declared = __TS__New(Set)
    local missing = __TS__New(Set)
    local noops = options.intentionalNoops or ({})
    for ____, name in ipairs(__TS__ObjectKeys(noops)) do
        if not __TS__ArraySome(
            options.declarations.functions,
            function(____, ____bindingPattern0)
                local native
                native = ____bindingPattern0[1]
                return native == name
            end
        ) or __TS__StringTrim(noops[name] or "") == "" then
            do
                local ____thrown = __TS__New(Error, ("intentional no-op " .. name) .. " needs a declared native and a concrete reason")
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/client.ts:197"
                end
                error(____thrown, 0)
            end
        end
    end
    for ____, ____value in ipairs(options.declarations.functions) do
        local name = ____value[1]
        local returns = ____value[2]
        local parameters = ____value[3]
        declared:add(name)
        arity:set(name, parameters)
        local fallback = self:defaultNative(returns)
        local behave = behaviors[name] or (__TS__StringStartsWith(name, "Convert") and (function(value) return value end) or (noops[name] ~= nil and fallback or (function()
            if not missing:has(name) then
                missing:add(name)
                local ____self_missingNatives_0 = self.missingNatives
                ____self_missingNatives_0[#____self_missingNatives_0 + 1] = {native = name, client = self.slot, frame = self.frame}
            end
            return fallback()
        end)))
        self.natives[name] = ____local[name] == nil and logged(name, parameters, behave) or behave
    end
    for ____, ____value in ipairs(options.declarations.constants) do
        local name = ____value[1]
        local ____type = ____value[2]
        local ____self_natives_4 = self.natives
        local ____name_5 = name
        local ____WARCRAFT3_ENUM_VALUES_name_3 = ____warcraft3Natives.WARCRAFT3_ENUM_VALUES[name]
        if ____WARCRAFT3_ENUM_VALUES_name_3 == nil then
            local ____temp_2
            if ____type == "number" then
                ____temp_2 = 0
            else
                local ____temp_1
                if ____type == "boolean" then
                    ____temp_1 = name == "TRUE"
                else
                    ____temp_1 = name
                end
                ____temp_2 = ____temp_1
            end
            ____WARCRAFT3_ENUM_VALUES_name_3 = ____temp_2
        end
        ____self_natives_4[____name_5] = ____WARCRAFT3_ENUM_VALUES_name_3
    end
    for ____, ____value in ipairs(options.declarations.variables) do
        local name = ____value[1]
        local ____type = ____value[2]
        self.natives[name] = self:defaultValue(____type)
    end
    local points = __TS__New(Map)
    do
        local index = 0
        while index < #____frames.FRAME_POINTS do
            local name, fromLeft, fromTop = table.unpack(____frames.FRAME_POINTS[index + 1] or ({"", 0, 0}), 1, 3)
            local ____points_set_7 = points.set
            local ____self_natives_name_6 = self.natives[name]
            if ____self_natives_name_6 == nil then
                ____self_natives_name_6 = name
            end
            ____points_set_7(points, ____self_natives_name_6, {fromLeft, fromTop})
            points:set(index, {fromLeft, fromTop})
            index = index + 1
        end
    end
    self.frames = __TS__New(____frames.Frames, points)
    self.frames:define(options.frames or ({}))
    local ____opt_8 = options.natives
    local extra = ____opt_8 and ____opt_8(self) or ({})
    for ____, name in ipairs(__TS__ObjectKeys(extra)) do
        local value = extra[name]
        self.natives[name] = type(value) == "function" and declared:has(name) and ____local[name] == nil and logged(
            name,
            arity:get(name) or 5,
            value
        ) or value
    end
end
function HeadlessClient.prototype.clockSeconds(self)
    return self.wallSeconds or self.frame / ____frameRate.FRAMES_PER_SECOND
end
function HeadlessClient.prototype.setWallTime(self, seconds)
    self.wallSeconds = seconds
end
function HeadlessClient.prototype.handle(self, kind)
    self.nextId = self.nextId + 1
    return {kind = kind, id = self.nextId}
end
function HeadlessClient.prototype.defaultNative(self, returns)
    repeat
        local ____switch40 = returns
        local ____cond40 = ____switch40 == "void"
        if ____cond40 then
            return function() return nil end
        end
        ____cond40 = ____cond40 or ____switch40 == "number"
        if ____cond40 then
            return function() return 0 end
        end
        ____cond40 = ____cond40 or ____switch40 == "string"
        if ____cond40 then
            return function() return "" end
        end
        ____cond40 = ____cond40 or ____switch40 == "boolean"
        if ____cond40 then
            return function() return false end
        end
        do
            return function() return self:handle(returns) end
        end
    until true
end
function HeadlessClient.prototype.defaultValue(self, ____type)
    if __TS__StringEndsWith(____type, "[]") then
        return {}
    end
    repeat
        local ____switch48 = ____type
        local ____cond48 = ____switch48 == "boolean"
        if ____cond48 then
            return false
        end
        ____cond48 = ____cond48 or ____switch48 == "number"
        if ____cond48 then
            return 0
        end
        ____cond48 = ____cond48 or ____switch48 == "string"
        if ____cond48 then
            return ""
        end
        do
            return self:handle(____type)
        end
    until true
end
function HeadlessClient.prototype.liveHandleCounts(self)
    return self.units:liveHandleCounts()
end
function HeadlessClient.prototype.behaviors(self, ____bindingPattern0)
    local screen
    local network
    local playerNames
    local humans
    humans = ____bindingPattern0.humans
    playerNames = ____bindingPattern0.playerNames
    network = ____bindingPattern0.network
    screen = ____bindingPattern0.screen
    local function handle(kind)
        return self:handle(kind)
    end
    local frameContext = {
        handle = handle,
        screen = screen,
        textAreaAutoScroll = self.textAreaAutoScroll,
        frames = function() return self.frames end,
        gameUiOrigin = function() return self.natives.ORIGIN_FRAME_GAME_UI end,
        keyPressed = function(key) return self.heldKeys:has(key) end,
        metaPressed = function(meta) return self.heldMeta & meta == meta end,
        mouseButtonPressed = function(button) return self.heldMouseButtons:has(button) end,
        mouseX = function() return self.mouseScreenX end,
        mouseY = function() return self.mouseScreenY end
    }
    return __TS__ObjectAssign(
        {},
        self.scenery:behaviors({handle = handle}),
        self.textTags:behaviors({
            handle = handle,
            unitPosition = function(unit)
                local live = unit
                local ____temp_10
                if live == nil or live.removed then
                    ____temp_10 = nil
                else
                    ____temp_10 = {x = live.x, y = live.y, z = live.z}
                end
                return ____temp_10
            end
        }),
        self.lightnings:behaviors({handle = handle}),
        self.inventory:behaviors(),
        self.units:playerBehaviors({slot = self.slot, humans = humans, playerNames = playerNames}),
        self.units:behaviors(),
        self.abilities:targetOrders({
            missing = function()
                local ____self_missingNatives_11 = self.missingNatives
                ____self_missingNatives_11[#____self_missingNatives_11 + 1] = {native = "IssueTargetOrder", client = self.slot, frame = self.frame}
            end,
            engageable = function(caster, target, range) return self.units:engageable(caster, target, range) end,
            now = function() return self.timers:time() end,
            hit = function(target, due, damage) return self.timers:hit(target, due, damage) end
        }),
        self.abilities:behaviors(handle),
        ____frames_2.inputNatives(frameContext),
        ____frames_2.frameNatives(frameContext),
        self.timers:behaviors(self.slot, network),
        self.preloadText:behaviors(),
        self.camera:behaviors(),
        self.sounds:behaviors(),
        self.effects:behaviors(),
        ____math.mathNatives()
    )
end
function HeadlessClient.prototype.preloadedFiles(self)
    return self.preloadText:preloadedFiles()
end
function HeadlessClient.prototype.effectPoses(self, options)
    if options == nil then
        options = {}
    end
    return self.effects:snapshot(options)
end
function HeadlessClient.prototype.cineFilterPose(self)
    return self.camera:cineFilterPose()
end
function HeadlessClient.prototype.cameraPose(self)
    return self.camera:cameraPose()
end
function HeadlessClient.prototype.unitPoses(self)
    return self.units:poses()
end
function HeadlessClient.prototype.run(self, body)
    local ____opt_12 = self.scope
    if ____opt_12 ~= nil then
        ____opt_12.enter(self)
    end
    do
        local ____try, ____error = pcall(function()
            body()
        end)
        do
            local ____opt_14 = self.scope
            if ____opt_14 ~= nil then
                ____opt_14.leave(self)
            end
        end
        if not ____try then
            error(____error, 0)
        end
    end
end
function HeadlessClient.prototype.step(self, draw)
    if draw == nil then
        draw = true
    end
    self.frame = self.frame + 1
    ____frameRate.steppedFrames.count = ____frameRate.steppedFrames.count + 1
    self.abilities:tick(__wispF32Divide(1, ____frameRate.FRAMES_PER_SECOND))
    self.scenery:tick(__wispF32Divide(1, ____frameRate.FRAMES_PER_SECOND))
    self.textTags:tick(__wispF32Divide(1, ____frameRate.FRAMES_PER_SECOND))
    if draw then
        self:draw(__wispF32Divide(1, ____frameRate.FRAMES_PER_SECOND))
    end
    self.effects:expire(self.frame)
    self.sounds:tick()
    self:run(function() return self.timers:runDue(self.frame) end)
    self.units:settleRemovals()
end
function HeadlessClient.prototype.draw(self, seconds)
    self.effects:draw(seconds)
    self.units:draw(seconds)
end
function HeadlessClient.prototype.deliverSync(self, message)
    self:run(function() return self.timers:deliverSync(message) end)
end
function HeadlessClient.prototype.chat(self, sender, message)
    self:run(function() return self.timers:chat(sender, message) end)
end
function HeadlessClient.prototype.key(self, sender, key, meta, down)
    if sender == self.slot then
        self:hold(key, meta, down)
    end
    self:keyEvent(sender, key, meta, down)
end
function HeadlessClient.prototype.hold(self, key, meta, down)
    self.heldMeta = meta
    if down then
        self.heldKeys:add(key)
    else
        self.heldKeys:delete(key)
    end
end
function HeadlessClient.prototype.keyEvent(self, sender, key, meta, down)
    self:run(function() return self.timers:keyEvent(sender, key, meta, down) end)
end
function HeadlessClient.prototype.type(self, text)
    return self.frames:type(text)
end
function HeadlessClient.prototype.clickTarget(self, x, y)
    local click = self.natives.FRAMEEVENT_CONTROL_CLICK
    return self.frames:at(
        x,
        y,
        function(frame) return self.timers:handles(frame, click) end
    )
end
function HeadlessClient.prototype.frameEvent(self, sender, id, event)
    self:run(function() return self.timers:frameEvent(sender, id, event) end)
end
function HeadlessClient.prototype.callCount(self)
    return self.forgotten + #self.log
end
function HeadlessClient.prototype.forget(self, count)
    local hash = self.forgottenHash
    do
        local index = 0
        while index < count do
            local call = self.log[index + 1]
            if call ~= nil then
                hash = ____callHash.mixCall(hash, call)
            end
            index = index + 1
        end
    end
    self.forgottenHash = hash
    __TS__ArraySplice(self.log, 0, count)
    self.forgotten = self.forgotten + count
end
function HeadlessClient.prototype.checksum(self)
    local hash = self.forgottenHash
    for ____, call in ipairs(self.log) do
        hash = ____callHash.mixCall(hash, call)
    end
    return ____jassFormat.describeNumber(hash)
end
return ____exports
