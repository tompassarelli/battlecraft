local ____lualib = require("lualib_bundle")
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local Set = ____lualib.Set
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local ____exports = {}
local ____binary32 = require("src.sim.binary32")
local ____f32 = require("src.sim.f32")
local ____animation = require("src.headless.animation")
local ____jassFormat = require("src.headless.jassFormat")
____exports.copyBlend = function(blend)
    local ____temp_0
    if blend == nil then
        ____temp_0 = nil
    else
        ____temp_0 = {
            from = __TS__ObjectAssign(
                {},
                blend.from,
                {subAnimations = {table.unpack(blend.from.subAnimations)}}
            ),
            remaining = blend.remaining
        }
    end
    return ____temp_0
end
local PLAYER_COLORS = __TS__ArrayMap(
    {
        "RED",
        "BLUE",
        "CYAN",
        "PURPLE",
        "YELLOW",
        "ORANGE",
        "GREEN",
        "PINK",
        "LIGHT_GRAY",
        "LIGHT_BLUE",
        "AQUA",
        "BROWN",
        "MAROON",
        "NAVY",
        "TURQUOISE",
        "VIOLET",
        "WHEAT",
        "PEACH",
        "MINT",
        "LAVENDER",
        "COAL",
        "SNOW",
        "EMERALD",
        "PEANUT",
        "BLACK"
    },
    function(____, name) return "PLAYER_COLOR_" .. name end
)
local DEATH_CUTOFF = 0xcf5c29p-25
local RADIANS_PER_DEGREE = 0x8efa35p-29
local DEGREES_PER_RADIAN = 0xe52ee1p-18
local TURN = 0xc90fdbp-21
--- Two ulps above the binary32 nearest 1 / TURN, as 3.0.1 multiplies by it.
local TURNS_PER_RADIAN = 0xa2f985p-26
local function unitFacing(degrees)
    local radians = ____binary32.multiplyFloat32TowardZero(degrees, RADIANS_PER_DEGREE)
    if radians >= TURN or radians < -TURN then
        local turns = ____binary32.multiplyFloat32TowardZero(radians, TURNS_PER_RADIAN)
        radians = ____binary32.multiplyFloat32TowardZero(
            __wispF32Subtract(
                turns,
                math.floor(turns)
            ),
            TURN
        )
    elseif radians < 0 then
        radians = ____binary32.subtractFloat32TowardZero(TURN, -radians)
    end
    return ____binary32.multiplyFloat32TowardZero(radians, DEGREES_PER_RADIAN)
end
____exports.Units = __TS__Class()
local Units = ____exports.Units
Units.name = "Units"
function Units.prototype.____constructor(self, states, handle, abilities)
    self.states = states
    self.handle = handle
    self.abilities = abilities
    self.live = __TS__New(Map)
    self.removals = {}
    self.passiveAlliances = __TS__New(Map)
    self.locations = __TS__New(Map)
    self.groups = __TS__New(Set)
end
function Units.prototype.liveHandleCounts(self)
    return {locations = self.locations.size, groups = self.groups.size}
end
function Units.prototype.create(self, owner, typeId, x, y, facing)
    local handle = self.handle("unit")
    local state = self.states[typeId]
    local unit = __TS__ObjectAssign(
        {},
        handle,
        ____animation.freshAnimation(),
        {
            handle = handle,
            typeId = typeId,
            owner = owner,
            x = x,
            y = y,
            z = 0,
            facing = unitFacing(facing),
            scale = {1, 1, 1},
            alpha = 255,
            color = {255, 255, 255},
            teamColor = owner,
            timeScale = 1,
            visible = true,
            moveSpeed = 0,
            attackCooldown = 0,
            life = state and state.life,
            maxLife = state and state.maxLife,
            mana = state and state.mana,
            maxMana = state and state.maxMana,
            dead = state ~= nil and state.life <= DEATH_CUTOFF,
            removed = false
        }
    )
    self.live:set(unit, unit)
    return unit
end
function Units.prototype.value(self, unit, field)
    if unit.removed then
        return 0
    end
    local value = unit[field]
    if value == nil then
        do
            local ____thrown = __TS__New(
                Error,
                ((((("unit type " .. tostring(unit.typeId)) .. ": declare unitStates.") .. tostring(unit.typeId)) .. ".") .. field) .. " or set it before reading"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/natives/units.ts:79"
            end
            error(____thrown, 0)
        end
    end
    return value
end
function Units.prototype.setLife(self, unit, life)
    if unit.removed then
        return
    end
    local value = unit.life == nil and life or ____binary32.addFloat32(
        unit.life,
        ____binary32.subtractFloat32(life, unit.life, true)
    )
    if not unit.dead and value <= DEATH_CUTOFF then
        unit.life = 0
        unit.dead = true
    else
        unit.life = value
    end
end
function Units.prototype.strike(self, target, damage)
    if self.live:has(target) and not target.dead then
        self:setLife(
            target,
            ____binary32.subtractFloat32(
                self:value(target, "life"),
                damage
            )
        )
    end
end
function Units.prototype.engageable(self, caster, target, range)
    if not self.live:has(caster) or not self.live:has(target) or caster.dead or target.dead or caster.owner == target.owner or self.passiveAlliances:get((tostring(caster.owner) .. " ") .. tostring(target.owner)) == true then
        return false
    end
    local dx = target.x - caster.x
    local dy = target.y - caster.y
    return not (dx * dx + dy * dy > range * range)
end
function Units.prototype.draw(self, seconds)
    for ____, unit in __TS__Iterator(self.live:values()) do
        ____animation.advanceAnimation(unit, unit.timeScale, seconds)
    end
end
function Units.prototype.settleRemovals(self)
    for ____, unit in ipairs(self.removals) do
        unit.removed = true
    end
    self.removals = {}
end
function Units.prototype.poses(self)
    local poses = {}
    for ____, unit in __TS__Iterator(self.live:values()) do
        poses[#poses + 1] = {
            handle = unit.handle,
            typeId = unit.typeId,
            owner = unit.owner,
            x = unit.x,
            y = unit.y,
            z = unit.z,
            facing = unit.facing,
            scale = {table.unpack(unit.scale)},
            alpha = unit.alpha,
            color = {table.unpack(unit.color)},
            teamColor = unit.teamColor,
            timeScale = unit.timeScale,
            visible = unit.visible,
            animation = unit.animation,
            subAnimations = {table.unpack(unit.subAnimations)},
            animationElapsed = unit.animationElapsed,
            animationClock = unit.animationClock,
            animationBlendTime = unit.animationBlendTime,
            animationBlend = ____exports.copyBlend(unit.animationBlend)
        }
    end
    return poses
end
function Units.prototype.playerBehaviors(self, ____bindingPattern0)
    local playerNames
    local humans
    local slot
    slot = ____bindingPattern0.slot
    humans = ____bindingPattern0.humans
    playerNames = ____bindingPattern0.playerNames
    local function playing(player)
        return __TS__ArrayIncludes(humans, player)
    end
    return {
        GetLocalPlayer = function() return slot end,
        Player = function(n) return n end,
        GetPlayerId = function(player) return player end,
        GetPlayerName = function(player) return playerNames and playerNames[player] or "Player " .. tostring(player + 1) end,
        GetHandleId = function(handle) return ____jassFormat.isHandle(handle) and handle.id or handle end,
        Location = function(x, y)
            local handle = self.handle("location")
            self.locations:set(handle, {x = x, y = y})
            return handle
        end,
        RemoveLocation = function(handle)
            self.locations:delete(handle)
        end,
        MoveLocation = function(handle, x, y)
            local location = self.locations:get(handle)
            if location ~= nil then
                location.x = x
                location.y = y
            end
        end,
        GetLocationX = function(handle)
            local ____opt_11 = self.locations:get(handle)
            return ____opt_11 and ____opt_11.x or 0
        end,
        GetLocationY = function(handle)
            local ____opt_13 = self.locations:get(handle)
            return ____opt_13 and ____opt_13.y or 0
        end,
        CreateGroup = function()
            local handle = self.handle("group")
            self.groups:add(handle)
            return handle
        end,
        DestroyGroup = function(handle)
            self.groups:delete(handle)
        end,
        GetPlayerController = function(player) return playing(player) and "MAP_CONTROL_USER" or "MAP_CONTROL_NONE" end,
        GetPlayerSlotState = function(player) return playing(player) and "PLAYER_SLOT_STATE_PLAYING" or "PLAYER_SLOT_STATE_EMPTY" end,
        GetPlayersAll = function()
            if self.allPlayers == nil then
                self.allPlayers = self.handle("force")
            end
            return self.allPlayers
        end,
        SetPlayerAlliance = function(source, target, which, allied)
            if which ~= "ALLIANCE_PASSIVE" then
                do
                    local ____thrown = __TS__New(Error, "SetPlayerAlliance: unsupported alliance " .. which)
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/natives/units.ts:157"
                    end
                    error(____thrown, 0)
                end
            end
            self.passiveAlliances:set(
                (tostring(source) .. " ") .. tostring(target),
                allied
            )
        end
    }
end
function Units.prototype.behaviors(self)
    local function animate(unit, animation)
        ____animation.selectAnimation(unit, animation)
    end
    return {
        CreateUnit = function(owner, typeId, x, y, facing) return self:create(
            owner,
            typeId,
            x,
            y,
            facing
        ) end,
        CreateUnitByName = function(owner, name, x, y, facing) return self:create(
            owner,
            #name == 4 and (string.byte(name, 1) or 0 / 0) * 16777216 + (string.byte(name, 2) or 0 / 0) * 65536 + (string.byte(name, 3) or 0 / 0) * 256 + (string.byte(name, 4) or 0 / 0) or 0,
            x,
            y,
            facing
        ) end,
        RemoveUnit = function(unit)
            local ____self_removals_15 = self.removals
            ____self_removals_15[#____self_removals_15 + 1] = unit
            self.live:delete(unit)
            self.abilities:removeUnit(unit)
        end,
        GetOwningPlayer = function(unit) return unit.owner end,
        GetWidgetLife = function(unit) return self:value(unit, "life") end,
        SetWidgetLife = function(unit, life) return self:setLife(unit, life) end,
        KillUnit = function(unit)
            if not unit.removed then
                unit.life = 0
                unit.dead = true
            end
        end,
        GetUnitState = function(unit, state)
            if state == "UNIT_STATE_LIFE" then
                return self:value(unit, "life")
            end
            if state == "UNIT_STATE_MAX_LIFE" then
                return self:value(unit, "maxLife")
            end
            if state == "UNIT_STATE_MANA" then
                return self:value(unit, "mana")
            end
            if state == "UNIT_STATE_MAX_MANA" then
                return self:value(unit, "maxMana")
            end
            do
                local ____thrown = __TS__New(Error, "GetUnitState: unsupported state " .. state)
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/natives/units.ts:178"
                end
                error(____thrown, 0)
            end
        end,
        SetUnitState = function(unit, state, value)
            if unit.removed then
                return
            end
            if state == "UNIT_STATE_LIFE" then
                self:setLife(unit, value)
            elseif state == "UNIT_STATE_MANA" then
                unit.mana = unit.mana == nil and value or ____binary32.addFloat32(
                    unit.mana,
                    ____binary32.subtractFloat32(value, unit.mana, true)
                )
            elseif state ~= "UNIT_STATE_MAX_LIFE" and state ~= "UNIT_STATE_MAX_MANA" then
                do
                    local ____thrown = __TS__New(Error, "SetUnitState: unsupported state " .. state)
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/natives/units.ts:185"
                    end
                    error(____thrown, 0)
                end
            end
        end,
        BlzGetUnitMaxHP = function(unit) return self:value(unit, "maxLife") end,
        BlzSetUnitMaxHP = function(unit, value)
            if not unit.removed then
                unit.maxLife = value
            end
        end,
        BlzGetUnitMaxMana = function(unit) return self:value(unit, "maxMana") end,
        BlzSetUnitMaxMana = function(unit, value)
            if not unit.removed then
                unit.maxMana = value
            end
        end,
        ShowUnit = function(unit, show)
            unit.visible = show
        end,
        IsUnitHidden = function(unit) return not unit.visible end,
        GetUnitFlyHeight = function(unit) return unit.z end,
        SetUnitFlyHeight = function(unit, height)
            unit.z = height
        end,
        GetUnitFacing = function(unit) return unit.facing end,
        SetUnitFacing = function(unit, facing)
            unit.facing = unitFacing(facing)
        end,
        BlzSetUnitFacingEx = function(unit, facing)
            unit.facing = unitFacing(facing)
        end,
        SetUnitScale = function(unit, x, y, z)
            unit.scale = {x, y, z}
        end,
        SetUnitTimeScale = function(unit, timeScale)
            unit.timeScale = timeScale
        end,
        SetUnitBlendTime = function(unit, blendTime)
            unit.animationBlendTime = blendTime
        end,
        SetUnitVertexColor = function(unit, red, green, blue, alpha)
            unit.color = {red, green, blue}
            unit.alpha = alpha
        end,
        SetUnitColor = function(unit, color)
            unit.teamColor = type(color) == "number" and color or __TS__ArrayIndexOf(PLAYER_COLORS, color)
        end,
        SetUnitAnimation = function(unit, animation) return animate(unit, animation) end,
        SetUnitAnimationByIndex = function(unit, animation) return animate(unit, animation) end,
        SetUnitAnimationWithRarity = function(unit, animation) return animate(unit, animation) end,
        GetUnitTypeId = function(unit) return unit.removed and 0 or unit.typeId end,
        GetUnitX = function(unit) return unit.x end,
        GetUnitY = function(unit) return unit.y end,
        SetUnitX = function(unit, x)
            unit.x = x
        end,
        SetUnitY = function(unit, y)
            unit.y = y
        end,
        SetUnitPosition = function(unit, x, y)
            unit.x = x
            unit.y = y
        end,
        SetUnitMoveSpeed = function(unit, value)
            unit.moveSpeed = value
        end,
        GetUnitMoveSpeed = function(unit) return unit.moveSpeed end
    }
end
return ____exports
