local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____lookup = require("src.runtime.lookup")
local ____capture = require("src.netcode.capture")
local ____fixedSchedule = require("src.netcode.fixedSchedule")
local ____frameRing = require("src.netcode.frameRing")
local ____ledger = require("src.netcode.ledger")
function ____exports.shadowSchedule(codec, players, history, correction)
    local previous = {}
    do
        local slot = 0
        while slot < players do
            previous[#previous + 1] = codec.neutral()
            slot = slot + 1
        end
    end
    return {
        codec = codec,
        fixed = ____fixedSchedule.fixedSchedule(codec, players, history),
        pending = ____frameRing.frameRing(
            codec,
            ____ledger.ledgerCapacity(history)
        ),
        previous = previous,
        history = history,
        correction = correction,
        epoch = ____ledger.NO_EPOCH,
        delay = 0,
        window = 0,
        nextSpeculative = 1,
        nextConfirmed = 1,
        preparedSpeculative = nil,
        preparedConfirmed = nil,
        acceptedPackets = 0
    }
end
function ____exports.maxInputDelay(correction)
    return ____ledger.FUTURE_LIMIT - correction - 2
end
function ____exports.beginShadowEpoch(schedule, epoch, delay, window, participants)
    if epoch <= schedule.epoch or window < 1 or window > schedule.correction or delay > ____exports.maxInputDelay(schedule.correction) then
        return false
    end
    if not ____fixedSchedule.beginFixedEpoch(schedule.fixed, epoch, delay, participants) then
        return false
    end
    schedule.epoch = epoch
    schedule.delay = delay
    schedule.window = window
    schedule.nextSpeculative = 1
    schedule.nextConfirmed = 1
    schedule.preparedSpeculative = nil
    schedule.preparedConfirmed = nil
    ____frameRing.ringClear(schedule.pending)
    for ____, row in ipairs(schedule.previous) do
        schedule.codec.copy(
            row,
            schedule.codec.neutral()
        )
    end
    return true
end
function ____exports.knownFrame(schedule)
    return schedule.fixed.ledger.known
end
function ____exports.confirmedLimit(schedule)
    return math.min(
        ____exports.knownFrame(schedule),
        schedule.nextSpeculative - 1
    )
end
function ____exports.awaitedSlots(schedule)
    local ledger = schedule.fixed.ledger
    local frame = ledger.known + 1
    local slots = 0
    do
        local slot = 0
        while slot < #ledger.rings do
            if ____ledger.isActive(ledger, slot) and ____ledger.acceptedRow(ledger, slot, frame) == nil then
                slots = slots | 1 << slot
            end
            slot = slot + 1
        end
    end
    return slots
end
function ____exports.othersThrough(schedule, ____local, frame)
    local ledger = schedule.fixed.ledger
    local through = frame
    do
        local slot = 0
        while slot < #ledger.rings do
            do
                if slot == ____local or not ____ledger.isPlaying(ledger, slot) then
                    goto __continue19
                end
                while through < ____ledger.LAST_FRAME and ____frameRing.ringRow(
                    ____lookup.at(ledger.rings, slot),
                    through + 1
                ) ~= nil do
                    through = through + 1
                end
            end
            ::__continue19::
            slot = slot + 1
        end
    end
    return through
end
function ____exports.remoteThrough(schedule, ____local)
    local ledger = schedule.fixed.ledger
    local through = ____ledger.NO_FRAME
    do
        local slot = 0
        while slot < #ledger.rings do
            local accepted = ____lookup.at(ledger.through, slot)
            if slot ~= ____local and ____ledger.isPlaying(ledger, slot) and accepted < through then
                through = accepted
            end
            slot = slot + 1
        end
    end
    return through
end
local function captureInto(schedule, frame, sample)
    if ____frameRing.ringRow(schedule.pending, frame) ~= nil then
        return ____capture.Capture.alreadyCaptured
    end
    if not ____frameRing.ringVacant(schedule.pending, frame) then
        return ____capture.Capture.pendingFull
    end
    ____frameRing.ringStore(schedule.codec, schedule.pending, frame, sample)
    return ____capture.Capture.captured
end
function ____exports.captureLocal(schedule, epoch, sample)
    if epoch ~= schedule.epoch then
        return ____capture.Capture.wrongEpoch
    end
    local target = ____fixedSchedule.captureTarget(schedule.nextSpeculative, schedule.delay)
    return target == nil and ____capture.Capture.frameExhausted or captureInto(schedule, target, sample)
end
function ____exports.captureLocalAt(schedule, epoch, frame, sample)
    if epoch ~= schedule.epoch then
        return ____capture.Capture.wrongEpoch
    end
    if frame < 1 or frame > ____ledger.LAST_FRAME then
        return ____capture.Capture.frameExhausted
    end
    local firstRetained = schedule.fixed.ledger.retainedFrom
    if frame < firstRetained then
        return ____capture.Capture.outOfHistory
    end
    if frame - (schedule.nextConfirmed - 1) > ____ledger.FUTURE_LIMIT then
        return ____capture.Capture.tooFarAhead
    end
    if frame - firstRetained >= #schedule.pending.frames then
        return ____capture.Capture.pendingFull
    end
    local assigned = ____frameRing.ringRow(schedule.pending, frame)
    if assigned ~= nil then
        return schedule.codec.same(assigned, sample) and ____capture.Capture.alreadyCaptured or ____capture.Capture.conflict
    end
    return captureInto(schedule, frame, sample)
end
function ____exports.acceptSynchronized(schedule, sender, firstFrame, rows, count)
    local receipt = ____ledger.acceptRows(
        schedule.fixed.ledger,
        sender,
        schedule.epoch,
        firstFrame,
        rows,
        count
    )
    if receipt == "accepted" then
        schedule.acceptedPackets = schedule.acceptedPackets + 1
    end
    return receipt
end
function ____exports.lateFrom(schedule, sender)
    return ____ledger.takeLowestAccepted(schedule.fixed.ledger, sender)
end
function ____exports.mayAdvanceSpeculative(schedule, ____local)
    return schedule.epoch ~= ____ledger.NO_EPOCH and schedule.nextSpeculative <= ____ledger.LAST_FRAME and schedule.nextSpeculative - schedule.window <= ____exports.remoteThrough(schedule, ____local) and schedule.nextSpeculative + 1 + schedule.delay - (schedule.nextConfirmed - 1) <= ____ledger.FUTURE_LIMIT
end
function ____exports.hasLocalRow(schedule, ____local)
    local frame = schedule.nextSpeculative
    return ____local < 0 or schedule.epoch ~= ____ledger.NO_EPOCH and (____ledger.acceptedRow(schedule.fixed.ledger, ____local, frame) ~= nil or ____frameRing.ringRow(schedule.pending, frame) ~= nil)
end
function ____exports.mayAdvanceSpeculativeFor(schedule, ____local)
    return (____local < 0 or ____ledger.isActive(schedule.fixed.ledger, ____local)) and ____exports.mayAdvanceSpeculative(schedule, ____local) and ____exports.hasLocalRow(schedule, ____local)
end
function ____exports.windowHalted(schedule, ____local)
    return schedule.epoch ~= ____ledger.NO_EPOCH and (____local < 0 or ____ledger.isActive(schedule.fixed.ledger, ____local)) and schedule.nextSpeculative <= ____ledger.LAST_FRAME and ____exports.hasLocalRow(schedule, ____local) and not ____exports.mayAdvanceSpeculative(schedule, ____local)
end
function ____exports.resolveSpeculative(schedule, epoch, ____local, inputs)
    if epoch ~= schedule.epoch or schedule.preparedSpeculative ~= nil or not ____exports.mayAdvanceSpeculativeFor(schedule, ____local) then
        return nil
    end
    local codec = schedule.codec
    local ledger = schedule.fixed.ledger
    local frame = schedule.nextSpeculative
    local resolution = "accepted"
    do
        local slot = 0
        while slot < #inputs do
            do
                if not ____ledger.isActive(ledger, slot) then
                    goto __continue48
                end
                local target = ____lookup.at(inputs, slot)
                local previous = ____lookup.at(schedule.previous, slot)
                local accepted = ____ledger.acceptedRow(ledger, slot, frame)
                if accepted ~= nil then
                    codec.copy(target, accepted)
                elseif slot == ____local then
                    local captured = ____frameRing.ringRow(schedule.pending, frame)
                    if captured == nil then
                        do
                            local ____thrown = __TS__New(
                                Error,
                                ("local input for frame " .. tostring(frame)) .. " was never captured"
                            )
                            if _G.__wispThrown ~= ____thrown then
                                _G.__wispThrown = ____thrown
                                _G.__wispThrowSite = "wisp/src/netcode/shadowSchedule.ts:179"
                            end
                            error(____thrown, 0)
                        end
                    end
                    codec.copy(target, captured)
                else
                    resolution = "speculative"
                    codec.hold(target, previous)
                end
                codec.copy(previous, target)
            end
            ::__continue48::
            slot = slot + 1
        end
    end
    schedule.preparedSpeculative = frame
    return resolution
end
function ____exports.completeSpeculative(schedule, epoch, frame)
    if epoch ~= schedule.epoch or frame ~= schedule.nextSpeculative or frame ~= schedule.preparedSpeculative then
        return false
    end
    schedule.preparedSpeculative = nil
    schedule.nextSpeculative = schedule.nextSpeculative + 1
    return true
end
function ____exports.rewindSpeculative(schedule, epoch, frame)
    if epoch ~= schedule.epoch or schedule.preparedSpeculative ~= nil or frame < schedule.nextConfirmed then
        return false
    end
    if frame < schedule.nextSpeculative then
        schedule.nextSpeculative = frame
    end
    return true
end
function ____exports.rememberResolvedInput(schedule, slot, row)
    if not ____ledger.isActive(schedule.fixed.ledger, slot) then
        return false
    end
    schedule.codec.copy(
        ____lookup.at(schedule.previous, slot),
        row
    )
    return true
end
function ____exports.mayAdvanceConfirmed(schedule)
    return schedule.epoch ~= ____ledger.NO_EPOCH and schedule.nextConfirmed <= ____exports.confirmedLimit(schedule)
end
function ____exports.readConfirmed(schedule, epoch, inputs)
    if epoch ~= schedule.epoch or schedule.preparedConfirmed ~= nil or not ____exports.mayAdvanceConfirmed(schedule) then
        return false
    end
    local frame = schedule.nextConfirmed
    if not ____fixedSchedule.readFixed(schedule.fixed, epoch, inputs) then
        return false
    end
    schedule.preparedConfirmed = frame
    return true
end
function ____exports.completeConfirmed(schedule, epoch, frame)
    if epoch ~= schedule.epoch or frame ~= schedule.nextConfirmed or frame ~= schedule.preparedConfirmed then
        return false
    end
    if not ____fixedSchedule.completeFixed(schedule.fixed, epoch, frame) then
        return false
    end
    schedule.preparedConfirmed = nil
    schedule.nextConfirmed = schedule.nextConfirmed + 1
    local expired = frame - schedule.history
    if expired >= 1 then
        ____frameRing.ringRelease(schedule.pending, expired)
    end
    return true
end
function ____exports.pendingRow(schedule, epoch, frame)
    local ____temp_0
    if epoch ~= schedule.epoch or frame < 1 or frame > ____ledger.LAST_FRAME then
        ____temp_0 = nil
    else
        ____temp_0 = ____frameRing.ringRow(schedule.pending, frame)
    end
    return ____temp_0
end
return ____exports
