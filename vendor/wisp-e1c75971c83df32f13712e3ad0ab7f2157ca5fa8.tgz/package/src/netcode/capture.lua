local ____exports = {}
____exports.Capture = {
    captured = 0,
    alreadyCaptured = 1,
    wrongEpoch = 2,
    frameExhausted = 3,
    pendingFull = 4,
    conflict = 6,
    outOfHistory = 7,
    tooFarAhead = 8
}
return ____exports
