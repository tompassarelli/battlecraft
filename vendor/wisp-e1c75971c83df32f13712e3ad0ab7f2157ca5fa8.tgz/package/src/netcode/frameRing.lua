local ____exports = {}
local ____lookup = require("src.runtime.lookup")
local ____intMath = require("src.sim.intMath")
local VACANT = -1
function ____exports.frameRing(codec, capacity)
    local frames = {}
    local rows = {}
    do
        local slot = 0
        while slot < capacity do
            frames[#frames + 1] = VACANT
            rows[#rows + 1] = codec.neutral()
            slot = slot + 1
        end
    end
    return {frames = frames, rows = rows}
end
function ____exports.ringRow(ring, frame)
    local slot = frame % #ring.frames
    local ____temp_0
    if ring.frames[slot + 1] == frame then
        ____temp_0 = ring.rows[slot + 1]
    else
        ____temp_0 = nil
    end
    return ____temp_0
end
function ____exports.ringVacant(ring, frame)
    return ____lookup.at(ring.frames, frame % #ring.frames) == VACANT
end
function ____exports.ringStore(codec, ring, frame, row)
    local slot = frame % #ring.frames
    codec.copy(
        ____lookup.at(ring.rows, slot),
        row
    )
    ring.frames[slot + 1] = frame
end
function ____exports.ringRelease(ring, frame)
    ring.frames[frame % #ring.frames + 1] = VACANT
end
function ____exports.ringClear(ring)
    do
        local slot = 0
        while slot < #ring.frames do
            ring.frames[slot + 1] = VACANT
            slot = slot + 1
        end
    end
end
return ____exports
