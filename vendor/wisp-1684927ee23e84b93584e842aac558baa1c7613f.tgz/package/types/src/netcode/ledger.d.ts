/** @noSelfInFile */
import type { RowCodec } from "./codec";
import { type FrameRing } from "./frameRing";
export declare const FUTURE_LIMIT = 128;
export declare const LEDGER_CAPACITY: number;
export type Receipt = "accepted" | "malformed" | "wrongSender" | "gone" | "outOfHistory" | "tooFarAhead" | "conflict";
export declare const STILL_PLAYING = 2147483647;
export interface InputLedger<Row> {
    readonly rings: readonly FrameRing<Row>[];
    readonly through: number[];
    readonly goneAfter: number[];
    readonly idle: Readonly<Row>;
}
export declare function inputLedger<Row>(codec: RowCodec<Row>, players: number, seeded: number): InputLedger<Row>;
export declare function isPlaying<Row>(ledger: InputLedger<Row>, player: number): boolean;
export declare function knownThrough<Row>(ledger: InputLedger<Row>): number;
export declare function acceptedRow<Row>(ledger: InputLedger<Row>, player: number, frame: number): Readonly<Row> | undefined;
export declare function leaveLedger<Row>(ledger: InputLedger<Row>, player: number): number;
export declare function acceptRows<Row>(codec: RowCodec<Row>, ledger: InputLedger<Row>, sender: number, firstFrame: number, rows: readonly Row[], count: number, confirmed: number): Receipt;
