import { appendFileSync } from "node:fs";
import { Console, Effect, Schema } from "effect";
import { captureProcess } from "../cli/hostProcess";

class MainRedFailure extends Schema.TaggedError<MainRedFailure, { readonly brand: unique symbol }>()("MainRedFailure", { command: Schema.String, problem: Schema.String }) {
  override get message(): string {
    return `${this.command}: ${this.problem}`;
  }
}

export const redTitle = (branch: string) => `${branch} is red`;
const TESTS_HEADING = "## Failing tests";

export function failingTests(log: string): string[] {
  const tests = new Set<string>();
  const steps = new Map<string, boolean>();
  for (const line of log.split("\n")) {
    const [job = "", step = "", stamped = ""] = line.split("\t");
    const text = stamped.replace(/^\S+Z /, "").replace(/\x1b\[[0-9;]*m/g, "");
    const key = `${job}: ${step.replace(/^Run /, "")}`;
    if (!steps.has(key)) steps.set(key, false);
    const bun = /^\(fail\) (.+?)(?: \[[\d.]+m?s\])?$/.exec(text);
    const lua = /^fail (.+?): /.exec(text);
    const name = bun?.[1] ?? (lua?.[1] === undefined ? undefined : `Lua32: ${lua[1]}`);
    if (name !== undefined) {
      tests.add(name);
      steps.set(key, true);
    }
  }
  const unnamed = [...steps].filter(([key, named]) => !named && key !== ": ").map(([key]) => `step ${key}`);
  return [...tests, ...unnamed];
}

export function issueTests(body: string): string[] {
  const section = body.split(TESTS_HEADING)[1]?.split("\n## ")[0] ?? "";
  return section.split("\n").flatMap((line) => (line.startsWith("- ") ? [line.slice(2)] : []));
}

interface Run { readonly databaseId: number; readonly conclusion: string; readonly status: string; readonly headSha: string; readonly url: string }

export function redIssueBody(branch: string, tests: readonly string[], runs: readonly Run[], repository: string): string {
  const [latest] = runs;
  const green = runs.findIndex((run) => run.conclusion === "success");
  const failed = (green === -1 ? runs : runs.slice(0, green)).filter((run) => run.conclusion === "failure");
  const first = failed.at(-1);
  const lastGreen = green === -1 ? undefined : runs[green];
  const short = (sha: string) => sha.slice(0, 10);
  return [
    `CI on \`${branch}\` is failing. Whoever landed the first failing commit owns the fix; nobody lands past this issue as "already failing".`,
    "",
    `- Latest failing run: ${latest?.url ?? "?"} (${short(latest?.headSha ?? "")})`,
    first === undefined ? "" : `- First failing commit: ${first.headSha} (${first.url})`,
    lastGreen === undefined
      ? "- Last green run: none in the recent history"
      : `- Last green commit: ${lastGreen.headSha}; commits that may have broken it: https://github.com/${repository}/compare/${short(lastGreen.headSha)}...${short(first?.headSha ?? latest?.headSha ?? "")}`,
    "",
    TESTS_HEADING,
    "",
    ...tests.slice(0, 200).map((test) => `- ${test}`),
    ...(tests.length > 200 ? [`- and ${tests.length - 200} more`] : []),
    "",
  ].filter((line, index, lines) => line !== "" || lines[index - 1] !== "").join("\n");
}

const gh = (...args: string[]) => captureProcess("gh", args.join(" "), ["gh", ...args]).pipe(
  Effect.mapError((cause) => new MainRedFailure({ command: `gh ${args[0]} ${args[1]}`, problem: String(cause) })),
  Effect.flatMap(({ exitCode, stdout, stderr }) => exitCode === 0 ? Effect.succeed(stdout) : Effect.fail(new MainRedFailure({ command: `gh ${args.join(" ")}`, problem: stderr.trim() }))),
);

const summary = (line: string) => Effect.sync(() => {
  if (process.env.GITHUB_STEP_SUMMARY !== undefined) appendFileSync(process.env.GITHUB_STEP_SUMMARY, `Main is red: ${line}\n`);
}).pipe(Effect.andThen(Console.log(`::notice title=Main is red::${line}`)));

const decode = <S extends Schema.Top>(schema: S, command: string) => (text: string) =>
  Schema.decodeEffect(Schema.fromJsonString(schema))(text).pipe(Effect.mapError((cause) => new MainRedFailure({ command, problem: String(cause) })));

const RunSchema = Schema.Struct({ databaseId: Schema.Finite, conclusion: Schema.String, status: Schema.String, headSha: Schema.String, url: Schema.String });
const ThisRun = Schema.Struct({ conclusion: Schema.String, headBranch: Schema.String, workflowName: Schema.String, databaseId: Schema.Finite });
const Issues = Schema.Array(Schema.Struct({ number: Schema.Finite, title: Schema.String }));
const Repository = Schema.Struct({ nameWithOwner: Schema.String });

export const reportRun = (runId: string) => Effect.gen(function*() {
  const run = yield* gh("run", "view", runId, "--json", "conclusion,headBranch,workflowName,databaseId").pipe(Effect.flatMap(decode(ThisRun, "gh run view")));
  if (run.conclusion !== "success" && run.conclusion !== "failure") return yield* Console.log(`run ${runId} ${run.conclusion || "unfinished"}: nothing to report`);
  const history = yield* gh("run", "list", "--workflow", run.workflowName, "--branch", run.headBranch, "--limit", "100",
    "--json", "databaseId,conclusion,status,headSha,url").pipe(Effect.flatMap(decode(Schema.Array(RunSchema), "gh run list")));

  const completed = history.filter((entry) => entry.conclusion === "success" || entry.conclusion === "failure");
  const index = completed.findIndex((entry) => entry.databaseId === run.databaseId);
  if (index > 0) return yield* Console.log(`run ${runId} is older than run ${completed[0]?.databaseId}: nothing to report`);
  const title = redTitle(run.headBranch);
  const open = (yield* gh("issue", "list", "--state", "open", "--search", `"${title}" in:title`, "--json", "number,title").pipe(Effect.flatMap(decode(Issues, "gh issue list"))))
    .filter((issue) => issue.title === title);
  if (run.conclusion === "success") {
    for (const { number } of open) yield* gh("issue", "close", String(number));
    const line = open.length === 0 ? `${run.headBranch} is green` : `${run.headBranch} is green again: closed #${open.map(({ number }) => number).join(", #")}`;
    yield* summary(line);
    return yield* Console.log(line);
  }
  const { nameWithOwner } = yield* gh("repo", "view", "--json", "nameWithOwner").pipe(Effect.flatMap(decode(Repository, "gh repo view")));
  const tests = failingTests(yield* gh("run", "view", runId, "--log-failed"));
  const body = redIssueBody(run.headBranch, tests, index === -1 ? completed : completed.slice(index), nameWithOwner);
  const [issue] = open;
  if (issue === undefined) {
    const url = yield* gh("issue", "create", "--title", title, "--body", body, "--label", "bug", "--label", "priority:now");
    yield* summary(`${run.headBranch} is red: opened ${url.trim()}, ${tests.length} failing`);
    return yield* Console.log(`opened ${url.trim()}: ${tests.length} failing`);
  }
  yield* gh("issue", "edit", String(issue.number), "--body", body);
  yield* summary(`${run.headBranch} is still red: updated #${issue.number}, ${tests.length} failing`);
  yield* Console.log(`updated #${issue.number}: ${tests.length} failing`);
});

if (import.meta.main) {
  const runId = process.argv[2];
  if (runId === undefined || !/^\d+$/.test(runId)) {
    console.error("usage: bun host/checks/mainRed.ts RUN_ID");
    process.exit(2);
  }
  await Effect.runPromise(reportRun(runId));
}
