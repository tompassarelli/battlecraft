local ____lualib = require("lualib_bundle")
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local ____exports = {}
local ____intMath = require("src.sim.intMath")
____exports.ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_"
____exports.WIRE_MAX_VALUE = 2147483646
function ____exports.digit(value)
    return __TS__StringCharAt(____exports.ALPHABET, value & 63)
end
function ____exports.varint(value)
    local text = ""
    local remaining = value
    repeat
        do
            local payload = remaining & 31
            remaining = remaining // 32
            text = text .. __TS__StringCharAt(____exports.ALPHABET, payload | (remaining > 0 and 32 or 0))
        end
    until not (remaining > 0)
    return text
end
function ____exports.signedVarint(value)
    return ____exports.varint(value < 0 and -2 * value - 1 or 2 * value)
end
function ____exports.wireReader(text, offset)
    return {text = text, offset = offset}
end
function ____exports.atEnd(reader)
    return reader.offset == #reader.text
end
function ____exports.readDigit(reader)
    if reader.offset >= #reader.text then
        return nil
    end
    local value = (string.find(
        ____exports.ALPHABET,
        __TS__StringCharAt(reader.text, reader.offset),
        nil,
        true
    ) or 0) - 1
    if value < 0 then
        return nil
    end
    reader.offset = reader.offset + 1
    return value
end
function ____exports.readVarint(reader, maximum)
    local value = 0
    local multiplier = 1
    do
        local index = 0
        while index < 7 do
            local read = ____exports.readDigit(reader)
            if read == nil then
                return nil
            end
            local payload = read & 31
            local last = read < 32
            if last and index > 0 and payload == 0 then
                return nil
            end
            if payload > (maximum - value) // multiplier then
                return nil
            end
            value = value + payload * multiplier
            if last then
                return value
            end
            multiplier = multiplier * 32
            index = index + 1
        end
    end
    return nil
end
function ____exports.readSignedVarint(reader, magnitude)
    local zigzag = ____exports.readVarint(reader, 2 * magnitude)
    if zigzag == nil then
        return nil
    end
    return zigzag & 1 == 1 and -((zigzag + 1) // 2) or zigzag // 2
end
return ____exports
