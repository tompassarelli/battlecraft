local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local ____exports = {}
local ____f32 = require("src.sim.f32")
local ____chatLog = require("src.ui.chatLog")
function ____exports.registerChatEvents(trigger, slots)
    for ____, slot in ipairs(slots) do
        TriggerRegisterPlayerChatEvent(
            trigger,
            Player(slot),
            "",
            false
        )
    end
end
function ____exports.registerChatHistoryKey(trigger, slots, key)
    for ____, slot in ipairs(slots) do
        BlzTriggerRegisterPlayerKeyEvent(
            trigger,
            Player(slot),
            key,
            0,
            true
        )
    end
end
____exports.ChatPanel = __TS__Class()
local ChatPanel = ____exports.ChatPanel
ChatPanel.name = "ChatPanel"
function ChatPanel.prototype.____constructor(self, style)
    self.style = style
    self.rowFrames = {}
    self.shownText = {}
    self.shownAlpha = {}
    self.rows = {}
    self.rowsKey = ""
    self.placedKey = ""
    self.shownRows = 0
    self.backdropAlpha = -1
    self.historyOpen = false
    self.log = ____chatLog.createChatLog(style.capacity)
    local parent = BlzGetOriginFrame(ORIGIN_FRAME_GAME_UI, 0)
    self.backdrop = BlzCreateFrameByType(
        "BACKDROP",
        style.name .. "Panel",
        parent,
        "",
        0
    )
    BlzFrameSetTexture(self.backdrop, style.panelTexture, 0, true)
    BlzFrameSetLevel(self.backdrop, style.level)
    BlzFrameSetEnable(self.backdrop, false)
    BlzFrameSetVisible(self.backdrop, false)
    do
        local index = 0
        while index < style.historyRows do
            local row = BlzCreateFrameByType(
                "TEXT",
                (style.name .. "Row") .. tostring(index),
                parent,
                "",
                0
            )
            BlzFrameSetLevel(row, style.level + 1)
            BlzFrameSetFont(row, style.font, style.fontSize, 0)
            BlzFrameSetTextAlignment(row, TEXT_JUSTIFY_MIDDLE, TEXT_JUSTIFY_LEFT)
            BlzFrameSetEnable(row, false)
            BlzFrameSetVisible(row, false)
            local ____self_rowFrames_0 = self.rowFrames
            ____self_rowFrames_0[#____self_rowFrames_0 + 1] = row
            local ____self_shownText_1 = self.shownText
            ____self_shownText_1[#____self_shownText_1 + 1] = ""
            local ____self_shownAlpha_2 = self.shownAlpha
            ____self_shownAlpha_2[#____self_shownAlpha_2 + 1] = -1
            index = index + 1
        end
    end
end
function ChatPanel.prototype.receive(self)
    local text = GetEventPlayerChatString()
    if self.style:ignore(text) then
        return
    end
    local player = GetTriggerPlayer()
    ____chatLog.addChatLine(
        self.log,
        self.style:colour(GetPlayerId(player)),
        GetPlayerName(player),
        text
    )
end
function ChatPanel.prototype.toggleHistory(self)
    if GetTriggerPlayer() == GetLocalPlayer() then
        self.historyOpen = not self.historyOpen
    end
end
function ChatPanel.prototype.update(self, seconds, box)
    ____chatLog.advanceChat(self.log, seconds)
    local rows = box == nil and ({}) or self:currentRows(box)
    if box == nil or #rows == 0 then
        self:hide()
        return
    end
    self:place(box, #rows)
    self:fill(rows)
end
function ChatPanel.prototype.currentRows(self, box)
    local history = self.historyOpen
    local seconds = history and -1.0 or self.style.recentSeconds
    local alive = 0
    for ____, line in ipairs(self.log.lines) do
        if seconds < 0.0 or ____chatLog.chatAge(self.log, line.born) < seconds then
            alive = alive + 1
        end
    end
    if alive == 0 then
        return {}
    end
    local count = history and self.style.historyRows or math.min(box.rows, self.style.historyRows)
    local width = __wispF32Divide(box.width, self.style.fontSize)
    local key = (((((((tostring(self.log.revision) .. ":") .. tostring(alive)) .. ":") .. tostring(count)) .. ":") .. tostring(width)) .. ":") .. tostring(seconds)
    if key ~= self.rowsKey then
        self.rowsKey = key
        self.rows = ____chatLog.visibleChatRows(
            self.log,
            count,
            width,
            self.style.glyphWidths,
            seconds
        )
    end
    return self.rows
end
function ChatPanel.prototype.place(self, box, count)
    local key = (((((tostring(box.left) .. ":") .. tostring(box.bottom)) .. ":") .. tostring(box.width)) .. ":") .. tostring(count)
    if key == self.placedKey then
        return
    end
    self.placedKey = key
    local ____self_style_3 = self.style
    local rowHeight = ____self_style_3.rowHeight
    local margin = ____self_style_3.margin
    local fontSize = ____self_style_3.fontSize
    local edge = math.max(
        0.0,
        __wispF32Subtract(
            margin,
            __wispF32Subtract(rowHeight, fontSize) * 0x1p-1
        )
    )
    BlzFrameClearAllPoints(self.backdrop)
    BlzFrameSetAbsPoint(
        self.backdrop,
        FRAMEPOINT_BOTTOMLEFT,
        __wispF32Subtract(box.left, margin),
        __wispF32Subtract(box.bottom, edge)
    )
    BlzFrameSetAbsPoint(
        self.backdrop,
        FRAMEPOINT_TOPRIGHT,
        __wispF32Add(box.left + box.width, margin),
        __wispF32Add(
            box.bottom + __wispF32Multiply(rowHeight, count),
            edge
        )
    )
    do
        local index = 0
        while index < count do
            local row = self.rowFrames[index + 1]
            BlzFrameClearAllPoints(row)
            BlzFrameSetAbsPoint(
                row,
                FRAMEPOINT_BOTTOMLEFT,
                box.left,
                __wispF32Add(
                    box.bottom,
                    __wispF32Multiply(rowHeight, count - 1 - index)
                )
            )
            BlzFrameSetSize(row, box.width, rowHeight)
            index = index + 1
        end
    end
end
function ChatPanel.prototype.fill(self, rows)
    local history = self.historyOpen
    local newest = 0.0
    do
        local index = 0
        while index < #self.rowFrames do
            do
                local row = self.rowFrames[index + 1]
                local shown = rows[index + 1]
                if shown == nil then
                    if index < self.shownRows then
                        BlzFrameSetVisible(row, false)
                    end
                    goto __continue29
                end
                if self.shownText[index + 1] ~= shown.text then
                    self.shownText[index + 1] = shown.text
                    BlzFrameSetText(row, shown.text)
                end
                local opacity = history and 1.0 or ____chatLog.chatOpacity(
                    ____chatLog.chatAge(self.log, shown.born),
                    self.style.recentSeconds,
                    self.style.fadeSeconds
                )
                newest = math.max(newest, opacity)
                local alpha = math.floor(__wispF32Multiply(opacity, 255.0))
                if self.shownAlpha[index + 1] ~= alpha then
                    self.shownAlpha[index + 1] = alpha
                    BlzFrameSetAlpha(row, alpha)
                end
                if index >= self.shownRows then
                    BlzFrameSetVisible(row, true)
                end
            end
            ::__continue29::
            index = index + 1
        end
    end
    local backdropAlpha = math.floor(__wispF32Multiply(newest, self.style.panelAlpha))
    if backdropAlpha ~= self.backdropAlpha then
        self.backdropAlpha = backdropAlpha
        BlzFrameSetAlpha(self.backdrop, backdropAlpha)
    end
    if self.shownRows == 0 then
        BlzFrameSetVisible(self.backdrop, true)
    end
    self.shownRows = #rows
end
function ChatPanel.prototype.hide(self)
    if self.shownRows == 0 then
        return
    end
    self.shownRows = 0
    self.placedKey = ""
    BlzFrameSetVisible(self.backdrop, false)
    for ____, row in ipairs(self.rowFrames) do
        BlzFrameSetVisible(row, false)
    end
end
return ____exports
