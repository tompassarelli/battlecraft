import { join } from "node:path";
import { Effect, Layer } from "effect";
import type { Platform } from "../os/platform/services";
import { documentsFolder, prefixFromDocuments } from "../os/warcraft/battleNet";
import * as desktop from "../os/warcraft/desktop";
import { type Command, type CommandFailure, UsageFailure } from "../cli/command";
import { type ClientProfile, clientSettings } from "../os/warcraft/clientProfiles";
import { DoctorHands, DoctorStop, type DoctorTarget, doctor, signOut } from "../doctor/doctor";
import { privateDoctorHands } from "../doctor/doctorHost";
import { PlayMachine } from "../play/play";
import { type PlayTools, playMachineLayer } from "../os/platform/play";
import type { ClientWatch } from "../dev/watch";

export interface DoctorDeclaration {

  readonly clientsFile: string;

  readonly start: Readonly<Record<string, Exclude<DoctorTarget["start"], { readonly kind: "offline-pool" }>>>;

  readonly accounts?: Readonly<Record<string, NonNullable<DoctorTarget["account"]>>>;
}

const profileSettings = (entry: { readonly profile?: ClientProfile | undefined; readonly displaySettings?: Readonly<Record<string, string>> | undefined }) => {
  const settings = clientSettings(entry.profile ?? "minimal");
  return { ...settings, Video: { ...settings["Video"], ...entry.displaySettings } };
};

const doctorTargets = (declaration: DoctorDeclaration, names: readonly string[] = []) => Effect.gen(function*() {
  const config = yield* desktop.readClientsFile(declaration.clientsFile).pipe(Effect.mapError((cause) => new DoctorStop({ problem: cause.message })));
  const unknown = names.filter((name) => !config.clients.some((client) => client.name === name));
  if (unknown.length > 0) return yield* new UsageFailure({ problem: `unknown client ${unknown.join(", ")}; known: ${config.clients.map(({ name }) => name).join(", ")}` });
  const chosen = names.length === 0 ? config.clients : config.clients.filter((client) => names.includes(client.name));
  return yield* Effect.forEach(chosen, (entry) => Effect.gen(function*() {
    const start = entry.offline === true ? { kind: "offline-pool" } as const : declaration.start[entry.name];
    if (start === undefined) return yield* new DoctorStop({ problem: `${entry.name}: the game declares no way to start its Battle.net` });
    const prefix = prefixFromDocuments(entry.documents);
    if (prefix === undefined) return yield* new DoctorStop({ problem: `${entry.name}: its documents folder isn't a Wine prefix's /${documentsFolder("")}: ${entry.documents}` });
    const display = yield* desktop.displayOf(entry).pipe(Effect.mapError((cause) => new DoctorStop({ problem: cause.message })));
    return {
      client: { name: entry.name, documents: entry.documents, ...(entry.menuReportPort === undefined ? {} : { menuReportPort: entry.menuReportPort }) },
      prefix,
      display,
      runtimeDir: join(entry.run, "runtime"),
      start,

      ...(entry.offline === true ? {} : { settings: profileSettings(entry) }),
      ...(declaration.accounts?.[entry.name] === undefined ? {} : { account: declaration.accounts[entry.name] }),
    } satisfies DoctorTarget;
  }));
});

const doctorLayer = (declaration: DoctorDeclaration, tools: Partial<PlayTools> = {}): Layer.Layer<PlayMachine | DoctorHands, CommandFailure, Platform> =>
  Layer.merge(playMachineLayer(tools), privateDoctorHands(declaration.clientsFile));

export const clientsDoctor = (declaration: DoctorDeclaration, names: readonly string[] = [], print: (line: string) => void = console.log, tools: Partial<PlayTools> = {}) =>
  Effect.gen(function*() {
    return yield* doctor(yield* doctorTargets(declaration, names), print);
  }).pipe(Effect.provide(doctorLayer(declaration, tools)));

export const makeDoctor = (declaration: DoctorDeclaration, watch: Layer.Layer<ClientWatch, CommandFailure, Platform>, tools: Partial<PlayTools> = {}): Command => (names) =>
  names.some((name) => name.startsWith("-"))
    ? Effect.fail(new UsageFailure({ problem: "doctor takes client names only" }))
    : clientsDoctor(declaration, names, (line) => console.log(line), tools).pipe(Effect.provide(watch), Effect.asVoid);

export const makeSignOut = (declaration: DoctorDeclaration, tools: Partial<PlayTools> = {}): Command => (names) =>
  names.length === 0 || names.some((name) => name.startsWith("-"))
    ? Effect.fail(new UsageFailure({ problem: "sign-out takes client names" }))
    : Effect.gen(function*() {
      const targets = yield* doctorTargets(declaration, names);
      yield* Effect.forEach(targets, (target) => signOut(target, (line) => console.log(line)), { discard: true });
    }).pipe(Effect.provide(playMachineLayer(tools)));
