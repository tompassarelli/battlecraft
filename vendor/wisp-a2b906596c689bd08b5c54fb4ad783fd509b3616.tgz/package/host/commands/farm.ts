import { parseArgs } from "node:util";
import { Effect } from "effect";
import { type Command, UsageFailure, describeCause } from "../cli/command";
import { farmTest } from "../farm/farm";

export const farm: Command = (args) => Effect.gen(function*() {
  const { values, positionals } = yield* Effect.try({
    try: () => parseArgs({ args: [...args], allowPositionals: true, options: { ref: { type: "string" }, wait: { type: "boolean" } } }),
    catch: (cause) => new UsageFailure({ problem: describeCause(cause) }),
  });
  switch (positionals[0]) {
    case "test":
      return yield* farmTest({ ref: values.ref, wait: values.wait === true });
    default:
      return yield* new UsageFailure({ problem: "farm test" });
  }
});
