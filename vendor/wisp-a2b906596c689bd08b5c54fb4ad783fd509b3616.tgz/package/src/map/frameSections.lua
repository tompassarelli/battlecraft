local ____exports = {}
local active
function ____exports.attachFrameSections(times)
    active = times
end
function ____exports.beginFrameSection(section)
    local times = active
    if times == nil then
        return
    end
    local clock = times.clock
    if clock ~= nil then
        times.started[section + 1] = clock()
    end
end
function ____exports.endFrameSection(section)
    local times = active
    if times == nil then
        return
    end
    local clock = times.clock
    if clock ~= nil then
        times.totals[section + 1] = (times.totals[section + 1] or 0) + clock() - (times.started[section + 1] or 0)
    end
end
return ____exports
