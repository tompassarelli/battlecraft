local ____lualib = require("lualib_bundle")
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local mixText, mixName, mixValue, mix, nameHashes, INT32_LIMIT
local ____jassFormat = require("src.headless.jassFormat")
function mixText(hash, text)
    local mixed = hash
    do
        local index = 0
        while index < #text do
            mixed = mix(
                mixed,
                __TS__StringCharCodeAt(text, index)
            )
            index = index + 1
        end
    end
    return mix(mixed, #text)
end
function mixName(hash, name)
    local named = nameHashes:get(name)
    if named == nil then
        named = mixText(0, name)
        nameHashes:set(name, named)
    end
    return mix(hash, named)
end
function mixValue(hash, value)
    if type(value) == "number" then
        if value == math.floor(value) and value >= -INT32_LIMIT and value < INT32_LIMIT then
            return mix(
                mix(hash, 1),
                math.floor(value)
            )
        end
        return mixText(
            mix(hash, 2),
            ____jassFormat.describeNumber(value)
        )
    end
    if type(value) == "string" then
        return mixText(
            mix(hash, 3),
            value
        )
    end
    if type(value) == "boolean" then
        return mix(hash, value and 4 or 5)
    end
    if type(value) == "function" then
        return mix(hash, 6)
    end
    if ____jassFormat.isHandle(value) then
        return mix(
            mixName(
                mix(hash, 7),
                value.kind
            ),
            value.id
        )
    end
    return mix(hash, (value == nil or value == nil) and 8 or 9)
end
mix = function(hash, value) return hash * 1000003 + value | 0 end
nameHashes = __TS__New(Map)
function ____exports.mixCall(hash, ____bindingPattern0)
    local args
    local name
    name = ____bindingPattern0.name
    args = ____bindingPattern0.args
    local mixed = mixName(hash, name)
    do
        local index = 0
        while index < #args do
            mixed = mixValue(mixed, args[index + 1])
            index = index + 1
        end
    end
    return mixed
end
INT32_LIMIT = 2147483648
return ____exports
