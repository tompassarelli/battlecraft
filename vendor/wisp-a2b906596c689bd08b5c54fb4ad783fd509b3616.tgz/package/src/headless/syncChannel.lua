local ____lualib = require("lualib_bundle")
local __TS__ArraySlice = ____lualib.__TS__ArraySlice
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArrayReduce = ____lualib.__TS__ArrayReduce
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__NumberIsInteger = ____lualib.__TS__NumberIsInteger
local Map = ____lualib.Map
local Set = ____lualib.Set
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local __TS__ArrayAt = ____lualib.__TS__ArrayAt
local __TS__ArrayEvery = ____lualib.__TS__ArrayEvery
local ____exports = {}
local ____random = require("src.headless.random")
local ____f32 = require("src.sim.f32")
local ____intMath = require("src.sim.intMath")
local ____frameRate = require("src.headless.frameRate")
do
    local ____frameRate = require("src.headless.frameRate")
    ____exports.EVEN_CALLBACKS = ____frameRate.EVEN_CALLBACKS
end
____exports.MEASURED_BATTLE_NET = {latencyMs = 80, turnMs = 25, extraTurns = {
    0xcccccdp-25,
    0xf5c28fp-26,
    0x24dd2fp-24,
    0x2c3c9fp-25,
    0x6a2b17p-27,
    0xfecdd1p-29,
    0x263879p-27,
    0x16eeafp-27,
    0x44cc0dp-28
}}
____exports.CALLBACK_MS = ____frameRate.FRAME_MS
local THIRDS_PER_MS = 3
local THIRDS_PER_FRAME = 50
local function ceilDiv(a, b)
    return -(-a // b)
end
local function arrivalThirds(latency, frame, extraTurns)
    local turnThirds = latency.turnMs * THIRDS_PER_MS
    return (ceilDiv(frame * THIRDS_PER_FRAME + latency.latencyMs * THIRDS_PER_MS, turnThirds) + extraTurns) * turnThirds
end
function ____exports.syncAgeMs(latency, frame, extraTurns)
    return (arrivalThirds(latency, frame, extraTurns) - frame * THIRDS_PER_FRAME) / THIRDS_PER_MS
end
local function turnBounds(probabilities)
    local bound = 0
    return __TS__ArrayMap(
        __TS__ArraySlice(probabilities, 0, -1),
        function(____, p)
            bound = bound + math.floor(p * 2147483648)
            return bound
        end
    )
end
local function turnsFor(bounds, state)
    do
        local turns = 0
        while turns < #bounds do
            if state < (bounds[turns + 1] or 0) then
                return turns
            end
            turns = turns + 1
        end
    end
    return #bounds
end
function ____exports.syncDelivery(latency, seed)
    if latency == nil then
        latency = ____exports.MEASURED_BATTLE_NET
    end
    if seed == nil then
        seed = 1
    end
    local total = __TS__ArrayReduce(
        latency.extraTurns,
        function(____, sum, p) return sum + p end,
        0
    )
    if math.abs(total - 1) > 0x8637bdp-43 then
        do
            local ____thrown = __TS__New(
                Error,
                ("extra-turn probabilities sum to " .. tostring(total)) .. ", not 1"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:58"
            end
            error(____thrown, 0)
        end
    end
    if not (latency.turnMs > 0) or not (latency.latencyMs >= 0) or not __TS__NumberIsInteger(latency.turnMs * THIRDS_PER_MS) or not __TS__NumberIsInteger(latency.latencyMs * THIRDS_PER_MS) then
        do
            local ____thrown = __TS__New(Error, "turn length must be positive and latency not negative, each in whole thirds of a millisecond")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:60"
            end
            error(____thrown, 0)
        end
    end
    local bounds = turnBounds(latency.extraTurns)
    local senders = __TS__New(Map)
    return {arrivalFrame = function(sender, frame, _message)
        local state = senders:get(sender)
        if state == nil then
            state = {
                random = __TS__New(____random.Random, seed * 7919 + sender * 104729 + 1),
                lastArrivalThirds = 0
            }
            senders:set(sender, state)
        end
        local arrival = math.max(
            state.lastArrivalThirds,
            arrivalThirds(
                latency,
                frame,
                turnsFor(
                    bounds,
                    state.random:nextState()
                )
            )
        )
        state.lastArrivalThirds = arrival
        return math.max(
            frame + 1,
            ceilDiv(arrival, THIRDS_PER_FRAME)
        )
    end}
end
function ____exports.replayedDelivery(arrivals, fallback, nowMs)
    local used = __TS__New(Set)
    local last = __TS__New(Map)
    return {arrivalFrame = function(sender, frame, message)
        local replayed = __TS__ArrayFind(
            arrivals(),
            function(____, arrival) return not used:has(arrival) and arrival.accepts(message) end
        )
        local arrival
        if replayed == nil then
            arrival = fallback.arrivalFrame(sender, frame, message)
        else
            used:add(replayed)
            arrival = frame + math.ceil((replayed.atMs - nowMs()) / ____exports.CALLBACK_MS - 0x89705fp-53)
        end
        arrival = math.max(
            frame + 1,
            last:get(sender) or 0,
            arrival
        )
        last:set(sender, arrival)
        return arrival
    end}
end
____exports.MEASURED_TURN_BURSTS = {turnMs = 25, jitterMs = 12, hitchChance = 0x51eb85p-30, hitchMeanMs = 30}
function ____exports.turnBursts(model, seed)
    if model == nil then
        model = ____exports.MEASURED_TURN_BURSTS
    end
    if seed == nil then
        seed = 1
    end
    if not (model.turnMs >= ____exports.CALLBACK_MS) or not __TS__NumberIsInteger(model.turnMs * THIRDS_PER_MS) or not (model.jitterMs >= 0) or not (model.hitchChance >= 0 and model.hitchChance < 1) or not (model.hitchMeanMs >= 0) then
        do
            local ____thrown = __TS__New(Error, "a turn must last at least one callback in whole thirds of a millisecond, and jitter, hitch chance and hitch length must not be negative")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:121"
            end
            error(____thrown, 0)
        end
    end
    local function turnOf(frame)
        return math.max(
            1,
            ceilDiv(frame * THIRDS_PER_FRAME, model.turnMs * THIRDS_PER_MS)
        )
    end
    local lag = 0
    local cycle = 6000
    do
        local frame = 1
        while frame <= cycle do
            lag = lag + (turnOf(frame) * model.turnMs - frame * ____exports.CALLBACK_MS)
            frame = frame + 1
        end
    end
    local offset = lag / cycle + model.jitterMs / 2 + model.hitchChance * model.hitchMeanMs
    local random = __TS__New(____random.Random, seed * 7919 + 15485863)
    local walls = {}
    local function turnWall(turn)
        while #walls < turn do
            local jitter = random:next() * model.jitterMs
            if random:chance(model.hitchChance) then
                jitter = jitter - model.hitchMeanMs * math.log(1 - random:next())
            end
            walls[#walls + 1] = math.max(
                __TS__ArrayAt(walls, -1) or 0,
                (#walls + 1) * model.turnMs + jitter - offset
            )
        end
        return walls[turn] or 0
    end
    return {wallMs = function(frame) return frame <= 0 and frame * ____exports.CALLBACK_MS or turnWall(turnOf(frame)) end}
end
____exports.MEASURED_RELAY = {steps = {8}, jitterMs = 2, links = {{rttMs = 120, loss = 0x51eb85p-28, depthTurns = 4}}}
____exports.RELAY_LAG_STOP_MS = 1000
____exports.RELAY_CATCH_UP_STEP_MS = 4
____exports.RELAY_SLEW_HOLD_MS = 30000
local function checkRelay(timing)
    if #timing.steps == 0 or not __TS__ArrayEvery(
        timing.steps,
        function(____, step) return step > ____exports.RELAY_CATCH_UP_STEP_MS end
    ) or not (timing.jitterMs >= 0) or #timing.links == 0 then
        do
            local ____thrown = __TS__New(
                Error,
                ("relay turns must be longer than " .. tostring(____exports.RELAY_CATCH_UP_STEP_MS)) .. " ms, jitter not negative, and at least one link given"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:181"
            end
            error(____thrown, 0)
        end
    end
    for ____, link in ipairs(timing.links) do
        if not (link.rttMs >= 0) or not (link.loss >= 0 and link.loss < 1) or not __TS__NumberIsInteger(link.depthTurns) or link.depthTurns < 0 then
            do
                local ____thrown = __TS__New(Error, "a relay link needs a round trip not negative, loss in [0, 1) and a whole depth not negative")
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:185"
                end
                error(____thrown, 0)
            end
        end
    end
    if timing.outage ~= nil and (not (timing.outage.atMs >= 0) or not (timing.outage.lengthMs >= 0)) then
        do
            local ____thrown = __TS__New(Error, "an outage must start and last at least 0 ms")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:188"
            end
            error(____thrown, 0)
        end
    end
end
local function relayShape(timing)
    local period = __TS__ArrayReduce(
        timing.steps,
        function(____, sum, step) return sum + step end,
        0
    )
    local meanStep = period / #timing.steps
    local ends = __TS__ArrayMap(
        timing.steps,
        function(____, _, index) return __TS__ArrayReduce(
            __TS__ArraySlice(timing.steps, 0, index + 1),
            function(____, sum, step) return sum + step end,
            0
        ) end
    )
    local function turnAfter(relayMs)
        local within = relayMs % period
        return relayMs - within + (__TS__ArrayFind(
            ends,
            function(____, ____end) return ____end > within end
        ) or period)
    end
    local function linkOf(sender)
        return timing.links[sender + 1] or __TS__ArrayAt(timing.links, -1) or ({rttMs = 0, loss = 0, depthTurns = 0})
    end
    local function depthMs(link)
        return link.depthTurns * meanStep
    end
    local outage = timing.outage
    local trailMs = math.max(table.unpack(__TS__ArrayMap(
        timing.links,
        function(____, link) return link.rttMs + depthMs(link) end
    )))
    local shallowMs = math.min(table.unpack(__TS__ArrayMap(
        timing.links,
        function(____, link) return depthMs(link) end
    )))
    local stopMs = outage == nil and 0 or math.min(
        outage.atMs + outage.lengthMs,
        outage.atMs + math.max(0, ____exports.RELAY_LAG_STOP_MS - trailMs)
    )
    local gapMs = outage == nil and 0 or outage.atMs + outage.lengthMs - stopMs
    local extraMs = outage == nil and 0 or outage.lengthMs - shallowMs - gapMs
    local drainMs = extraMs > 2 * meanStep and (extraMs - meanStep) * meanStep / (meanStep - ____exports.RELAY_CATCH_UP_STEP_MS) or 0
    local settledMs = extraMs > 2 * meanStep and meanStep or extraMs
    local function wallMs(gameMs)
        if outage == nil or gameMs <= outage.atMs or outage.lengthMs <= shallowMs then
            return gameMs
        end
        local since = gameMs - outage.atMs
        local extra
        if since < drainMs then
            extra = extraMs - since * (meanStep - ____exports.RELAY_CATCH_UP_STEP_MS) / meanStep
        elseif since < drainMs + ____exports.RELAY_SLEW_HOLD_MS then
            extra = settledMs
        else
            extra = math.max(0, settledMs - (since - drainMs - ____exports.RELAY_SLEW_HOLD_MS) / meanStep)
        end
        return gameMs + gapMs + extra
    end
    return {
        meanStep = meanStep,
        turnAfter = turnAfter,
        linkOf = linkOf,
        depthMs = depthMs,
        outage = outage,
        stopMs = stopMs,
        gapMs = gapMs,
        wallMs = wallMs
    }
end
function ____exports.relayDelivery(timing, seed)
    if timing == nil then
        timing = ____exports.MEASURED_RELAY
    end
    if seed == nil then
        seed = 1
    end
    checkRelay(timing)
    local shape = relayShape(timing)
    local anchorFraction = -math.log(0xf33333p-24)
    local senders = __TS__New(Map)
    local function ageMs(sender, frame)
        local state = senders:get(sender)
        if state == nil then
            state = {
                random = __TS__New(____random.Random, seed * 7919 + sender * 104729 + 3),
                lastArrivalMs = 0
            }
            senders:set(sender, state)
        end
        local link = shape.linkOf(sender)
        local sentMs = frame * ____exports.CALLBACK_MS
        local upMs = shape.wallMs(sentMs) + link.rttMs / 2 + timing.jitterMs * anchorFraction + shape.depthMs(link)
        do
            while true do
                if shape.outage ~= nil and upMs >= shape.outage.atMs and upMs < shape.outage.atMs + shape.outage.lengthMs then
                    upMs = shape.outage.atMs + shape.outage.lengthMs
                elseif state.random:chance(link.loss) then
                    upMs = upMs + shape.meanStep
                else
                    break
                end
            end
        end
        upMs = upMs + (link.rttMs / 2 - timing.jitterMs * math.log(1 - state.random:next()))
        local relayMs = upMs
        if shape.outage ~= nil and upMs >= shape.stopMs then
            relayMs = upMs < shape.outage.atMs + shape.outage.lengthMs and shape.stopMs or upMs - shape.gapMs
        end
        local arrivalMs = math.max(
            state.lastArrivalMs,
            shape.turnAfter(relayMs)
        )
        state.lastArrivalMs = arrivalMs
        return arrivalMs - sentMs
    end
    return {
        ageMs = function(sender, frame) return ageMs(sender, frame) end,
        arrivalFrame = function(sender, frame, _message) return math.max(
            frame + 1,
            math.ceil(frame + ageMs(sender, frame) / ____exports.CALLBACK_MS - 0x89705fp-53)
        ) end
    }
end
function ____exports.relayCallbacks(timing)
    if timing == nil then
        timing = ____exports.MEASURED_RELAY
    end
    checkRelay(timing)
    local shape = relayShape(timing)
    return {wallMs = function(frame) return frame <= 0 and frame * ____exports.CALLBACK_MS or shape.wallMs(frame * ____exports.CALLBACK_MS) end}
end
return ____exports
