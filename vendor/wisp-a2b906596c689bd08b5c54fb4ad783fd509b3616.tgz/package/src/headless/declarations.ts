export interface NativeDeclarations {

  readonly functions: readonly (readonly [name: string, returns: string, parameters: number])[];
  readonly constants: readonly (readonly [name: string, type: string])[];

  readonly variables: readonly (readonly [name: string, type: string])[];
}

function declaredName(line: string, keyword: string): string | undefined {
  const start = keyword.length;
  let end = start;
  while (end < line.length) {
    const character = line.charAt(end);
    if (character === "(" || character === ":" || character === " ") break;
    end++;
  }
  return end > start ? line.slice(start, end) : undefined;
}

function declaredType(line: string): string | undefined {
  if (!line.endsWith(";")) return undefined;
  for (let colon = line.length - 2; colon > 0; colon--) {
    if (line.charAt(colon) === ":" && line.charAt(colon + 1) === " ") return line.slice(colon + 2, line.length - 1);
  }
  return undefined;
}

function declaredParameters(line: string, from: number): number {
  let depth = 0;
  let count = 0;
  let any = false;
  for (let index = line.indexOf("(", from); index < line.length; index++) {
    const character = line.charAt(index);
    if (character === "(") {
      depth++;
      continue;
    }
    if (character === ")") {
      depth--;
      if (depth === 0) break;
      continue;
    }
    if (depth === 1 && character === ",") count++;
    else if (character !== " ") any = true;
  }
  return any ? count + 1 : 0;
}

export function parseNativeDeclarations(text: string): NativeDeclarations {
  const functions: (readonly [string, string, number])[] = [];
  const constants: (readonly [string, string])[] = [];
  const variables: (readonly [string, string])[] = [];
  for (const line of text.split("\n")) {
    const keyword = line.startsWith("declare function ") ? "declare function "
      : line.startsWith("declare const ") ? "declare const "
        : line.startsWith("declare let ") ? "declare let " : undefined;
    if (keyword === undefined) continue;
    const name = declaredName(line, keyword);
    const type = declaredType(line.trim());
    if (name === undefined || type === undefined) continue;
    if (keyword === "declare function ") functions.push([name, type, declaredParameters(line, keyword.length + name.length)]);
    else if (keyword === "declare const ") constants.push([name, type]);
    else variables.push([name, type]);
  }
  return { functions, constants, variables };
}
