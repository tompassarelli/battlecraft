local ____lualib = require("lualib_bundle")
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local ____exports = {}
local ____jassFormat = require("src.headless.jassFormat")
function ____exports.mathNatives()
    return {
        I2S = function(n) return ____jassFormat.describeNumber(n) end,
        R2S = function(n) return ____jassFormat.fixed(n, 3) end,
        R2SW = function(n, width, precision)
            local text = ____jassFormat.fixed(n, precision > 0 and precision or 0)
            if precision <= 0 then
                text = text .. ".0"
            end
            while #text < width + 1 do
                text = " " .. text
            end
            return text
        end,
        R2I = function(n) return n < 0 and math.ceil(n) or math.floor(n) end,
        I2R = function(n) return n end,
        S2I = function(text)
            local value = ____jassFormat.leadingNumber(text, false)
            return value < 0 and math.ceil(value) or math.floor(value)
        end,
        S2R = function(text) return ____jassFormat.leadingNumber(text, true) end,
        SubString = function(text, start, ____end) return __TS__StringSubstring(text, start, ____end) end,
        StringLength = function(text) return #text end,
        SquareRoot = function(n) return math.sqrt(n) end,
        Atan2 = function(y, x) return math.atan(y, x) end,
        BlzBitAnd = function(a, b) return a & b end,
        BlzBitOr = function(a, b) return a | b end,
        BlzBitXor = function(a, b) return a ~ b end
    }
end
return ____exports
