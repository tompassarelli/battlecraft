local ____exports = {}
local ____binary32 = require("src.sim.binary32")
____exports.after = function(at, length)
    local due = ____binary32.addFloat32TowardZero(at, length)
    return due > at and due or ____binary32.addFloat32TowardZero(at, at * 0x1p-23)
end
return ____exports
