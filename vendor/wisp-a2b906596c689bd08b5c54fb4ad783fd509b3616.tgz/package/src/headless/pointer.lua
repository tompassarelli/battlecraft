local ____exports = {}
function ____exports.point(client, x, y, left)
    client.mouseScreenX = x
    client.mouseScreenY = y
    if left == true then
        client.heldMouseButtons:add(client.natives.MOUSE_BUTTON_TYPE_LEFT)
    elseif left == false then
        client.heldMouseButtons:delete(client.natives.MOUSE_BUTTON_TYPE_LEFT)
    end
end
return ____exports
