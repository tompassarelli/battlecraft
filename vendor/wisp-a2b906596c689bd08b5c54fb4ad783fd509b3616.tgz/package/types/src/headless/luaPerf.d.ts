/** @noSelfInFile */
import { type Journey } from "./journey";
import { Lockstep, type SyncDelivery } from "./lockstep";
import { type LuaHeadlessMap } from "./lua";
import { type NativeCostModel } from "./nativeCost";
import { type PerfCollector } from "./perfCollector";
export declare const HOOK_STEP = 100;
declare global {
    function collectgarbage(option: "requested"): number;
    function collectgarbage(option: "step", size: number): boolean;
}
export interface PerfMeasure {
    typed(this: void, slot: number, characters: number): void;
    begin(this: void): void;
}
export interface LuaPerfOptions {
    readonly model?: NativeCostModel;
    readonly samples?: boolean;
    readonly delivery?: SyncDelivery;
    readonly collector?: PerfCollector;
}
export declare const TOP_SHARE: number;
export declare function runLuaPerfWith(map: LuaHeadlessMap, bundlePath: string, declarationsPath: string, play: (this: void, clients: Lockstep, measure: PerfMeasure) => {
    readonly problems: number;
    readonly lines: readonly string[];
}, options?: LuaPerfOptions): number;
export declare function runLuaPerf(map: LuaHeadlessMap, journey: Journey, bundlePath: string, declarationsPath: string, options?: LuaPerfOptions): number;
export declare const OUTSIDE_MAP = -1;
export interface AllocationSampler {
    start(this: void, into: Map<number, [self: number, inclusive: number]>): void;
    stop(this: void): void;
}
export declare function allocationSampler(source?: string): AllocationSampler;
