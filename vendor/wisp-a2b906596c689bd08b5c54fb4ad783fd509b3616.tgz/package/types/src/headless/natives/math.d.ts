/** @noSelfInFile */
import type { NativeBehavior } from "../clientTypes";
export declare function mathNatives(): Readonly<Record<string, NativeBehavior>>;
