/** @noSelfInFile */
import type { HandleFactory, NativeBehavior, PlayerMouseInput, SyncMessage } from "../clientTypes";
import type { Frame } from "../frames";
import type { Unit, Units } from "./units";
/** One player's synchronized mouse event at world coordinates: its player event, and its button for a press or release. */
export interface PlayerMouse {
    readonly event: unknown;
    readonly x: number;
    readonly y: number;
    readonly button: unknown;
}
export declare function playerMouseEvent(natives: Readonly<Record<string, unknown>>, input: PlayerMouseInput): PlayerMouse;
export declare class TriggersTimers {
    private readonly handle;
    private readonly units;
    private readonly timers;
    private readonly spellHits;
    private timerOrder;
    private now;
    private readonly registrations;
    private readonly event;
    constructor(handle: HandleFactory, units: Units);
    time(): number;
    hit(target: Unit, due: number, damage: number): void;
    private fire;
    private timerElapsed;
    runDue(frame: number): void;
    deliverSync({ sender, prefix, data }: SyncMessage): void;
    chat(sender: number, message: string): void;
    keyEvent(sender: number, key: number, meta: number, down: boolean): void;
    playerMouse(sender: number, { event, x, y, button }: PlayerMouse): void;
    frameEvent(sender: number, id: number, event: unknown): void;
    handles(frame: Frame, event: unknown): boolean;
    behaviors(slot: number, network: SyncMessage[]): Readonly<Record<string, NativeBehavior>>;
    private triggerBehaviors;
}
