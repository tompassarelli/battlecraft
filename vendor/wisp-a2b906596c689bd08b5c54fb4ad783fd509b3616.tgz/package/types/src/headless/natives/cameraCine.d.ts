/** @noSelfInFile */
import type { CameraPose, CineFilterPose, NativeBehavior } from "../clientTypes";
import type { Scenery } from "../warcraft3Scenery";
export declare class CameraCine {
    private readonly scenery;
    private readonly frame;
    private cameraX;
    private cameraY;
    private readonly cameraFields;
    private readonly cineFilter;
    constructor(scenery: Scenery, frame: (this: void) => number);
    cineFilterPose(): CineFilterPose | undefined;
    cameraPose(): CameraPose;
    behaviors(): Readonly<Record<string, NativeBehavior>>;
}
