/** @noSelfInFile */
/** Warcraft III's simulation rate, which headless clients, lockstep peers and the renderers step at. */
export declare const FRAMES_PER_SECOND = 60;
export declare const FRAME_MS: number;
/** Frames headless clients have stepped in this process: a test's deterministic cost (wisp:host/testing/testCostPreload.ts). */
export declare const steppedFrames: {
    count: number;
};
export interface CallbackTiming {
    wallMs(this: void, frame: number): number;
}
export declare const EVEN_CALLBACKS: CallbackTiming;
export declare function turnStart(timing: CallbackTiming | undefined, frame: number): number;
export declare function stampWallTime(timing: CallbackTiming | undefined, clients: readonly {
    setWallTime(seconds: number): void;
}[], frame: number): void;
