/** @noSelfInFile */
export type PerfCollector = "stopped" | "incremental";
export declare const PERF_COLLECTOR_VARIABLE = "WISP_PERF_COLLECTOR";
