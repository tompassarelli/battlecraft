/** @noSelfInFile */
type Fields = Readonly<Record<string, unknown>>;
declare const isFields: (value: unknown) => value is Fields;
declare const MAX_DEPTH = 32;
declare function valueText(value: unknown): string | undefined;
declare const isFieldName: (text: string) => boolean;
export declare class IntegerKeysUndeclared extends Error {
}
interface Writer {
    readonly parts: string[];
    count: number;
    keyed: Readonly<Record<string, boolean>>;
    keyedFrom: readonly string[] | undefined;
    readonly path: string[];
}
declare const writer: Writer;
declare function token(name: string, mark: string, text: string): void;
declare function indexName(index: number): string;
declare function keyedName(key: string): string;
declare function arrayLength(value: Fields): number | undefined | false;
declare function isKeyed(value: Fields): boolean;
export declare function recordTokens(record: object, keyedByInteger?: readonly string[]): string[] | undefined;
export declare function writeFieldTokens(name: string, value: unknown, keyedByInteger?: readonly string[]): number | undefined;
export { MAX_DEPTH, arrayLength, indexName, isFieldName, isFields, isKeyed, keyedName, token, valueText, writer };
export interface TokenLines {
    width: number;
    prefix: string;
    lines: string[];
    readonly parts: string[];
    size: number;
    tokens: number;
    length: number;
}
export declare function createTokenLines(prefix: string, width: number, lines?: string[]): TokenLines;
export declare function openTokenLines(sink: TokenLines, prefix: string, width: number, lines: string[]): void;
export declare function addToken(sink: TokenLines, text: string): void;
export declare function addWrittenToken(sink: TokenLines, index: number, name?: string): void;
export declare function addWrittenTokens(sink: TokenLines, count: number): void;
export declare function endTokenLine(sink: TokenLines): void;
export declare function parseRecord(tokens: readonly string[]): Record<string, unknown> | undefined;
export declare function tokenLines(tokens: readonly string[], width: number): string[];
export declare function lineTokens(lines: readonly string[]): string[];
