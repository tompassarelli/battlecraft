/** @noSelfInFile */
export declare const TWO_POWERS: number[];
export interface Limbs {
    high: number;
    middle: number;
    low: number;
}
export declare function shiftRightJam(value: Limbs, count: number): Limbs;
export declare function addLimbs(a: Limbs, b: Limbs): Limbs;
export declare function lessThan(a: Limbs, b: Limbs): boolean;
export declare function subtractLimbs(a: Limbs, b: Limbs): Limbs;
export declare function bitLength(value: number): number;
