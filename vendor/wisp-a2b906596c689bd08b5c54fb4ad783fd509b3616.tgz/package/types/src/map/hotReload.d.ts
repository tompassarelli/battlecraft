/** @noSelfInFile */
export declare function installHotReload(): void;
export declare function startHotReload(): void;
